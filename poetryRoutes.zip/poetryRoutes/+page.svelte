<script lang="ts">
	const { data } = $props();
</script>

<h1 class="text-2xl font-bold">Poetry Database</h1>
<p>Welcome to the poetry database. Browse poets and read their works.</p>

<ul>
	{#each data.poets as poet}
		<li>
			<a href={poet.name} class="no-underline hover:text-gray-400 hover:underline">{poet.name}</a>
			<span>({poet.poemCount} poems)</span>
		</li>
	{/each}
</ul>

