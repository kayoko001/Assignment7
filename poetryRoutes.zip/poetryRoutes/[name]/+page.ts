import { type PoemData } from '$lib/index';

export async function load({ fetch, params }) {
	const apiUrl = `https://ochre.uchicago.edu/digs30005-poetry-database/poet/${encodeURIComponent(params.name)}`;

	const response = await fetch(apiUrl);
	if (!response.ok) {
		throw new Error('Response failed!');
	}

	const data: PoemData = await response.json();

	return data;
}
