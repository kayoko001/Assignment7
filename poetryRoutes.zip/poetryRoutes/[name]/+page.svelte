<script lang="ts">
	import type { Poem } from '$lib/index';
	import { Input } from '@repo/ui/components/ui/input';

	const { data } = $props();
	let search: string = $state<string>('');
	const poems: Array<Poem> = data.poems;
	//console.log(poems);

	let filteredPoems: Array<Poem> = $derived(
		search === ''
			? poems
			: poems.filter((poem) => {
					const searchLower = search.toLocaleLowerCase();
					const titleMatch = poem.title.toLocaleLowerCase().includes(searchLower);
					const lineMatch = poem.poem.some((line) =>
						line.toLocaleLowerCase().includes(searchLower)
					);
					return titleMatch || lineMatch;
				})
	);
</script>

<div class="container mx-auto mt-4 font-bold text-red-800 hover:text-red-600">
	<a href="/">Return to main list</a>
</div>
<div class="container mx-auto prose prose-sm prose-zinc">
	<h1 class="mt-4 text-3xl">Poems of {data.name}</h1>
	<p class="pb-4">{filteredPoems.length} Poems</p>
	<Input
		type="text"
		bind:value={search}
		class="w-2/3 sm:w-96 rounded-sm border-2"
		placeholder="Filter poems by title or content"
	/>
	{#if filteredPoems.length === 0}
		<div>No matching results.</div>
	{:else}
		<div class="">
			<ol class="list-decimal">
				{#each filteredPoems as poem, i (`${poem.title}-${i}`)}
					<li class="">{poem.title}</li>
				{/each}
			</ol>
			{#each filteredPoems as poem, i (`${poem.title}-${i}`)}
				<div class="">
					<p class="font-bold">{poem.title}</p>
					{#each poem.poem as line}
						<p class="leading-1">{line}</p>
					{/each}
				</div>
			{/each}
		</div>
	{/if}
</div>
