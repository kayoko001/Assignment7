import { type PoetData } from "$lib/index";

export async function load({ fetch }) {
  const apiUrl = "https://ochre.uchicago.edu/digs30005-poetry-database";

  const response = await fetch(apiUrl);
  if (!response.ok) {
    throw new Error("Response failed!");
  }

  const poets: PoetData = await response.json();

  return { poets };
}
